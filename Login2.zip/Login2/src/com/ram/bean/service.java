package com.ram.bean;
import java.text.SimpleDateFormat;
import java.util.Date;

public class service 
{
	LoginBean bean= new LoginBean();

	public int valid()
	{
		String a1="admin";
		int i=0;
		if(a1.equals(LoginBean.getUser()) && a1.equals(LoginBean.getPwd()))
		{
			i=1;
		}
		else
		{
			i=0;
		}
		return i;
		
	}
	public  String date()
	{
		Date date = new Date();//date 
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");  
		String str=(formatter.format(date));
		bean.setDate(str);
		System.out.println(str);
		return str;
	}

}
