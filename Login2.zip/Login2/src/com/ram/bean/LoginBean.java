package com.ram.bean;

public class LoginBean 
{
	private static String user;
	private static String pwd;
	private static String date;
	public static String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public static String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public static String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
}
