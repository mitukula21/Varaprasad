package com.ram.bean;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/loginAction")
public class LoginController extends HttpServlet
{

	public  void doGet(HttpServletRequest request,HttpServletResponse response)  throws ServletException,IOException
	{
		
		response.setContentType("text/html");//for wrting html code
		PrintWriter out=response.getWriter();
		
		String user=request.getParameter("username");//reading the value of username
		String pass=request.getParameter("Password");
		LoginBean bean = new LoginBean();
		bean.setPwd(pass);
		bean.setUser(user);
		try //exception handling
		{
			RequestDispatcher rd = null;
			PrintWriter out1 = response.getWriter();
			service ser = new service();
			ser.date();
			int updateCount= ser.valid();
			if (updateCount==1)
			{
				rd = request.getRequestDispatcher("/Success.jsp");	
				rd.forward(request, response);
			} else 
			{
				rd = request.getRequestDispatcher("/Login.jsp");
				rd.include(request, response);
				out1.println("Enter the correct credential....");
			}
			
			
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
}

}
