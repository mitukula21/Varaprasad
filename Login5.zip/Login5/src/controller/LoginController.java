package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import services.LoginService;

//import com.ram.services.BookService;

public class LoginController extends HttpServlet
{
public  void doGet(HttpServletRequest request,HttpServletResponse response) 
   throws ServletException,IOException 
{
	RequestDispatcher rd = null;
	String username="";
	String password="";
	
	
	
	
	username=request.getParameter("username");
	password=request.getParameter("password");
	
	
		
		
		LoginService bookService = new LoginService();
		
		
   int updateCount = bookService.addStudentService(username,password);
		
		System.out.println("inserted "+updateCount+" record   Success");
		
		if (updateCount==1) {
			rd = request.getRequestDispatcher("/success.jsp");
			
		} else {
			rd = request.getRequestDispatcher("/error.jsp");
		}
		rd.forward(request, response);
	}
		
		
		
}