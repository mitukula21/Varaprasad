import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appcomponent',
  templateUrl: './appcomponent.component.html',
  styleUrls: ['./appcomponent.component.css']
})
export class AppcomponentComponent implements OnInit {

  
  constructor() 
  { 
 
  }
  ngOnInit() {
  }

}
