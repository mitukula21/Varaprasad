import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  //title = 'basic1';

  serverElement =[{ type :'server' ,name:'test server',content:'just a test'}]

  onserveradded(severData :{serverName :string ,serverContent :string}){
    this.serverElement.push({
     type:'server',
     name : severData.serverName,
     content:severData.serverContent

    });
  }
  onblueprintadded(blueprintData :{serverName :string ,serverContent :string}){
    this.serverElement.push({
     type:'blueprint',
     name:blueprintData.serverName,
     content:blueprintData.serverContent

    });

  }
  /*serverElement =[];
  newServerName='';
  newServerContent='';



   onAddServer(){
    this.serverElement.push({
     type:'server',
     name: this.newServerName,
     content:this.newServerContent

    });
  }

    onAddBluePrint(){
      this.serverElement.push({
       type:'blueprint',
       name:this.newServerName,
       content:this.newServerContent
      });

    }*/



  
  
  }
