package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class loginController extends HttpServlet
{

	public  void doGet(HttpServletRequest request,HttpServletResponse response)  throws ServletException,IOException
	{
		response.setContentType("text/html");//for wrting html code
		PrintWriter out=response.getWriter();
		
		String user=request.getParameter("username");//reading the value of username
		String pass=request.getParameter("Password");
		
		try //exception handling
		{
			if (pass.equals("admin") )//validating the password
			{
			HttpSession session=request.getSession();
			session.setAttribute("user",user);
			session.setAttribute("pass",pass);
			Date date = new Date();//date 
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");  
			String str=(formatter.format(date));
			out.print("<html><body bgcolor=#39CCCC> <center><h1>Welcome User!!!"+user+"</h1><br><marquee><h2>Date:"+str+"</h2></marquee></center></body></html>");
			request.getRequestDispatcher("/Success.jsp").include(request, response);
			
			}
			else
			{
				out.print("<html><body><center><h1>Please Enter Correct Credentails!</h1></center></body></html>");//error page
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
}
}
