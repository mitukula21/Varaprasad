
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class StudentController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	try {
		response.setContentType("text/html");  
		RequestDispatcher rd=null;
		PrintWriter out = response.getWriter();
		String sname = request.getParameter("sname");
		String sdept = request.getParameter("sdept");
		String marks = request.getParameter("marks");
		String phoneno =request.getParameter("phoneno");
		String percentage =request.getParameter("percentage");
			out.println("Welcome User!!! " + sname);
		
		      
			HttpSession session = request.getSession();
			session.setAttribute("sname", sname);
			session.setAttribute("sdept", sdept);
			session.setAttribute("marks", marks);
			session.setAttribute("phoneno", phoneno);
			session.setAttribute("percentage", percentage);
		
			rd = request.getRequestDispatcher("/Success.html");
			rd.forward(request, response);
			
		}
	catch(Exception e)
	{
		System.out.println(e);
	}
		
		
	}
}
