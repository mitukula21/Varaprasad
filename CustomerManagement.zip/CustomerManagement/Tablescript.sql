create table patient1(pid number(10),
pname varchar2(20),age number(10),
pno varchar2(20),pdesc varchar2(20),
pdate date);

 create sequence pid_sequence start with 1000;