package com.capgemini.customerapplication.service;

import java.util.List;

import com.capgemini.customerapplication.bean.CustomerBean;
import com.capgemini.customerapplication.exception.CustomerException;

public interface ICustomerService 
{
	public String addCustomerDetails(CustomerBean donor) throws CustomerException;
	public String updateCustomerDetails(CustomerBean donor2) throws CustomerException;
	public List<CustomerBean> retriveAll()throws CustomerException;
	public String loginadmin(String email) throws CustomerException; ;

	public CustomerBean deleteCustomerDetails(String donorId) throws CustomerException;
}
