package com.capgemini.customerapplication.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.omg.CORBA.UserException;

import com.capgemini.customerapplication.bean.CustomerBean;
import com.capgemini.customerapplication.dao.CustomerDaoImpl;
import com.capgemini.customerapplication.dao.ICustomerDAO;
import com.capgemini.customerapplication.exception.CustomerException;

public class CustomerServiceImpl implements ICustomerService {
	
	ICustomerDAO customerDao;
	
	
	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addCustomerDetails
	 - Input Parameters	:	donor object
	 - Return Type		:	String id
	 - Throws			:  	DonorException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	11/11/2016
	 - Description		:	adding donor to database calls dao method addCustomerDetails(donor)
	 ********************************************************************************************************/
	public String addCustomerDetails(CustomerBean donor) throws CustomerException {
		customerDao=new CustomerDaoImpl();	
		String donorSeq;
		donorSeq= customerDao.addCustomerDetails(donor);
		return donorSeq; 
	}

	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	deleteCustomerDetails
	 - Input Parameters	:	String donorId
	 - Return Type		:	donor object
	 - Throws		    :  	DonorException
	 - Author		    :	CAPGEMINI
	 - Creation Date	:	18/11/2016
	 - Description		:	calls dao method deleteCustomerDetails(donorId)
	 ********************************************************************************************************/
	public String updateCustomerDetails(CustomerBean donor) throws CustomerException {
		customerDao=new CustomerDaoImpl();	
		String donorSeq;
		donorSeq= customerDao.updateCustomerDetails(donor);
		return donorSeq; 
	}


	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	: retriveAll()
	 - Input Parameters	:	
	 - Return Type		: list
	 - Throws		    : DonorException
	 - Author	      	: CAPGEMINI 
	 - Creation Date	: 18/11/2016
	 - Description		: calls dao method retriveAllDetails()
	 ********************************************************************************************************/
	public List<CustomerBean> retriveAll() throws CustomerException {
		customerDao=new CustomerDaoImpl();
		List<CustomerBean> donorList=null;
		donorList=customerDao.retriveAllDetails();
		return donorList;
	}
	
	
	/*public DonorBean deleteCustomerDetails(String pid) throws DonorException {
		customerDao=new customerDaoImpl();
		DonorBean bean=null;
		bean=customerDao.deleteCustomerDetails(pid);
		return bean;
	}*/
	
	
	public CustomerBean deleteCustomerDetails(String pid) throws CustomerException {
		customerDao=new CustomerDaoImpl();
		CustomerBean bean=null;
		bean=customerDao.deleteCustomerDetails(pid);
		return bean;
	}
	
	
	
	
	public String loginadmin(String email) throws CustomerException {
		CustomerDaoImpl userDao=new CustomerDaoImpl();
		String pwd = null;
		try {
			pwd = userDao.loginadmin(email);
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
 
		return pwd;
 
	}
	
	/*******************************************************************************************************
	 - Function Name	: validateDonor(DonorBean bean)
	 - Input Parameters	: DonorBean bean
	 - Return Type		: void
	 - Throws		    : DonorException
	 - Author	      	: CAPGEMINI
	 - Creation Date	: 18/11/2016
	 - Description		: validates the DonorBean object
	 ********************************************************************************************************/
	public void validateDonor(CustomerBean bean) throws CustomerException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating donor name
		if(!(isValidEmail(bean.getEmail()))) {
			validationErrors.add("\n Please Enter a valid Email Address ! \n");
		}
		
		if(!(isValidPassword(bean.getPassword()))) {
			validationErrors.add("\n Customer Password Should Be In Alphabets and minimum 6 characters long ! \n");
		}
		
		if(!(isValidPhoneNumber(bean.getPhonenumber()))) {
			validationErrors.add("\n Not a valid 10-digit  phone number (must not include spaces or special characters,should start with 6-9) \n");
		}
		
		if(!(isValidAddress(bean.getAddress()))) {
			validationErrors.add("\n Customer"
					+ " Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		if(!(isValidAddress(bean.getCity()))) {
			validationErrors.add("\n Donar Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		if(!(isValidZipcode(bean.getZipcode()))) {
			validationErrors.add("\n Donar Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		
		
	
	}

	/*public boolean isValidName(String donorName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(donorName);
		return nameMatcher.matches();
	}*/
	public boolean isValidName(String donorName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(donorName);
		return nameMatcher.matches();
	}
	public boolean isValidPassword(String donorName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{6,}$");
		Matcher nameMatcher=namePattern.matcher(donorName);
		return nameMatcher.matches();
	}
 
	public boolean isValidAddress(String address){
		return (address.length() > 3);
	}
 
	public boolean isValidPhoneNumber(String phoneNumber){
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
 
	}
 
	public boolean isValidZipcode(String zipCode){
		Pattern phonePattern=Pattern.compile("^[0-9]{6}$");
		Matcher phoneMatcher=phonePattern.matcher(zipCode);
		return phoneMatcher.matches();
 
	}
 
	public boolean isValidEmail(String email) {
 
		Pattern emailpattern=Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
		Matcher emailmatcher = emailpattern.matcher(email);
		return emailmatcher.matches();
 
 
	}
 
	/*public boolean isValidAmount(String amount){
		Pattern phonePattern=Pattern.compile("{9}$");
		Matcher phoneMatcher=phonePattern.matcher(amount);
		return phoneMatcher.matches();
		//return (amount>0);
	}*/
	public boolean validateDonorId(String donorId) {
 
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(donorId);
 
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
}
	


