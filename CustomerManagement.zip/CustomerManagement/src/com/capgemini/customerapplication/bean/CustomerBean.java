package com.capgemini.customerapplication.bean;

import java.util.Date;


public class CustomerBean 
{
	private String cid;
	private String email;
	private String password;
	private String phonenumber;
	private String address;
	private String city;
	private String zipcode;
	private String country;
	private String fullname;
	private Date registrationdate;
	
	
	
	public String getCid() {
		return cid;
	}






	public void setCid(String cid) {
		this.cid = cid;
	}






	public String getFullname() {
		return fullname;
	}






	public void setFullname(String fullname) {
		this.fullname = fullname;
	}






	public Date getRegistrationdate() {
		return registrationdate;
	}






	public void setRegistrationdate(Date registrationdate) {
		this.registrationdate = registrationdate;
	}









	


	public String getEmail() {
		return email;
	}






	public void setEmail(String email) {
		this.email = email;
	}






	public String getPassword() {
		return password;
	}






	public void setPassword(String password) {
		this.password = password;
	}






	public String getPhonenumber() {
		return phonenumber;
	}






	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}






	public String getAddress() {
		return address;
	}






	public void setAddress(String address) {
		this.address = address;
	}






	public String getCity() {
		return city;
	}






	public void setCity(String city) {
		this.city = city;
	}






	public String getZipcode() {
		return zipcode;
	}






	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}






	public String getCountry() {
		return country;
	}






	public void setCountry(String country) {
		this.country = country;
	}






	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Printing  Customer Details \n");
		sb.append("Customer Email: " +email +"\n");
		sb.append("Customer Password: "+ password +"\n");
		sb.append("Custoemr phonenumber: "+ phonenumber +"\n");
		sb.append("Customer Address "+ address +"\n");
		sb.append("Customer City "+ city+"\n");
		sb.append("Customer Zipcode "+ zipcode +"\n");
		sb.append("Customer Country "+ country +"\n");
		return sb.toString();
	}
	

	
}
