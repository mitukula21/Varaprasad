package com.capgemini.customerapplication.pi;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.customerapplication.bean.CustomerBean;
import com.capgemini.customerapplication.exception.CustomerException;
import com.capgemini.customerapplication.service.CustomerServiceImpl;
import com.capgemini.customerapplication.service.ICustomerService;

public class CustomerMain {

	static Scanner sc = new Scanner(System.in);
	static ICustomerService customerService = null;
	static CustomerServiceImpl customerServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		CustomerBean customerBean = null;

		String cid = null;
		String email=null;
		String password=null;
		int option = 0;
		
		
		
		
		
		System.out.println("--------------WELCOME------------");
					 System.out.println("enter the email :");
					 String loginemail = sc.next();
					 System.out.println("enter the password :");
					 String pwd = sc.next();
					 CustomerServiceImpl userService = new CustomerServiceImpl();
					// userService.loginadmin(loginemail,pwd);
					String realpwd = null;
					try {
						realpwd = userService.loginadmin(loginemail);
					} catch (CustomerException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		 
					 if (realpwd.equals(pwd))
					 {
		
		

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   CUSTOMER MANAGEMENT APPLICATION   ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add New Customer ");
			System.out.println("2.Edit Customer details ");
			System.out.println("3.Listing All Customers ");
			System.out.println("4.Delete Customer Record ");
			System.out.println("5.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (customerBean == null) {
						customerBean = populatecustomerBean();
						// System.out.println(customerBean);
					}

					try {
						customerService = new CustomerServiceImpl();
						cid = customerService.addCustomerDetails(customerBean);

						System.out.println("Customer details  has been successfully registered ");
						System.out.println("Customer ID Is: " + cid);

					} catch (CustomerException donorException) {
						logger.error("exception occured", donorException);
						System.err.println("ERROR : "+ donorException.getMessage());
					} finally {
						cid = null;
						customerService = null;
						customerBean = null;
					}

					break;

				case 2:

					customerServiceImpl = new CustomerServiceImpl();

					
					while (customerBean == null) {
						customerBean = populatecustomerBean2();
						// System.out.println(customerBean);
					}
	 
					try {
						customerService = new CustomerServiceImpl();
						cid = customerService.updateCustomerDetails(customerBean);
	 
						System.out.println("customer details  has been successfully updated ");
	 
	 
					} catch (CustomerException donorException) {
						logger.error("exception occured", donorException);
						System.err.println("ERROR : "+ donorException.getMessage());
					} finally {
						cid = null;
						customerService = null;
						customerBean = null;
					}
	 
					break;
	 
					

				case 3:

					customerService = new CustomerServiceImpl();
					try {
						List<CustomerBean> donorList = new ArrayList<CustomerBean>();
						donorList = customerService.retriveAll();

						if (donorList != null) {
							Iterator<CustomerBean> i = donorList.iterator();
							while (i.hasNext()) {
								System.out.println(i.next());
							}
						} else {
							System.out
							.println("There are no Customer Records present.");
						}

					}

					catch (CustomerException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;
					
					
				case 4:
					
					customerServiceImpl = new CustomerServiceImpl();
					 
					System.out.println("Enter  the customer id you want to delete:");
					cid = sc.next();
 
					while (true) {
						if (customerServiceImpl.validateDonorId(cid)) {
							break;
						} else {
							System.err
									.println("Please enter numeric Customer id only, try again");
							cid = sc.next();
						}
					}
 
					try {
						customerBean = getDonorDetails(cid);
					} catch (CustomerException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
 

				case 5:

					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
					 }
	}// end of try

	
	private static CustomerBean populatecustomerBean2() 
	{

		// TODO Auto-generated method stub
		CustomerBean customerBean2 = new CustomerBean();
		//update customer set name=?,city=?,EMAIL=? where customer_ID=?
		System.out.println("\n Enter Details to be updated ");

		System.out.println("Enter Customer Id: ");
		customerBean2.setCid(sc.next());

		System.out.println("Enter Customer New Email: ");
		customerBean2.setEmail(sc.next());

		System.out.println("Enter Customer  New Password: ");
		customerBean2.setPassword(sc.next());

		

	customerServiceImpl = new CustomerServiceImpl();

	try {
		customerServiceImpl.updateCustomerDetails(customerBean2);
		return customerBean2;
	} catch (CustomerException donorException) {
		logger.error("exception occured", donorException);
		System.err.println("Invalid data:");
		System.err.println(donorException.getMessage() + " \n Try again..");
		System.exit(0);
	}
		return null;
	}
	
	
	
	
	
	private static CustomerBean getDonorDetails(String donorId) throws CustomerException {
		CustomerBean customerBean = null;
		customerService = new CustomerServiceImpl();
 
		customerBean = customerService.deleteCustomerDetails(donorId);
 
		customerService = null;
		return customerBean;
	}
 
	
	
	/*
	 * This function will call the service layer method and return the bean
	 * object which is populated by the information of the given donorId in
	 * parameter
	 */

	/*
	 * This function will be called by main and will return a validated bean
	 * object OR null if details are invalid
	 */
	private static CustomerBean populatecustomerBean() {

		// Reading and setting the values for the customerBean
		
		CustomerBean customerBean = new CustomerBean();

		System.out.println("\n Enter Customer Details");

		System.out.println("Enter Customer Email: ");
		customerBean.setEmail(sc.next());

		System.out.println("Enter Customer password: ");
		customerBean.setPassword(sc.next());

		System.out.println("Enter Customer phonenumber: ");
		customerBean.setPhonenumber(sc.next());

		System.out.println("Enter Customer Address : ");
		Scanner sc1=new Scanner(System.in);
        customerBean.setAddress(sc1.next());
        
        System.out.println("Enter Customer City : ");
        customerBean.setCity(sc.next());
        
        System.out.println("Enter Customer Zipcode : ");
        customerBean.setZipcode(sc.next());
        
        System.out.println("Enter Customer Country : ");
        customerBean.setCountry(sc.next());
        
        System.out.println("Enter Customer FullName : ");
        Scanner sc2=new Scanner(System.in);
        customerBean.setFullname(sc2.next());
		

		customerServiceImpl = new CustomerServiceImpl();

		try {
			customerServiceImpl.validateDonor(customerBean);
			return customerBean;
		} catch (CustomerException donorException) {
			logger.error("exception occured", donorException);
			System.err.println("Invalid data:");
			System.err.println(donorException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
