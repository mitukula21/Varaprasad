package com.capgemini.customerapplication.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.omg.CORBA.UserException;

import com.capgemini.customerapplication.bean.CustomerBean;
import com.capgemini.customerapplication.bean.LoginBean;
import com.capgemini.customerapplication.exception.CustomerException;
import com.capgemini.customerapplication.util.DBConnection;


public class CustomerDaoImpl implements ICustomerDAO 
{
	
	Logger logger=Logger.getRootLogger();
	public CustomerDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	

	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addCustomerDetails(DonorBean donor)
	 - Input Parameters	:	DonorBean donor
	 - Return Type		:	String
	 - Throws			:  	DonorException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/11/2018
	 - Description		:	Adding Donor
	 ********************************************************************************************************/

	@SuppressWarnings("resource")
	public String addCustomerDetails(CustomerBean donor) throws CustomerException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String donorId=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,donor.getEmail());			
			preparedStatement.setString(2,donor.getPassword());
			preparedStatement.setString(3,donor.getPhonenumber());
			preparedStatement.setString(4,donor.getAddress());
			preparedStatement.setString(5,donor.getCity());
			preparedStatement.setString(6,donor.getZipcode());
			preparedStatement.setString(7,donor.getCountry());
			preparedStatement.setString(8,donor.getFullname());
			
			
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.DONARID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				donorId=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new CustomerException("Inserting Customer details failed ");

			}
			else
			{
				logger.info("Customer details added successfully:");
				return donorId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new CustomerException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustomerException("Error in closing db connection");

			}
		}
		
		
	}
	
	
	
	
	//---------------------------------------------------------//
	
	
	
	public CustomerBean deleteCustomerDetails(String cid) throws CustomerException {
		 
		Connection connection=DBConnection.getInstance().getConnection();
 
 
		PreparedStatement preparedStatement=null;
		int resultset;
		CustomerBean bean=null;
 
		try
		{
			preparedStatement=connection.prepareStatement(QueryMapper. DELETE_DONAR_DETAILS_QUERY);
			preparedStatement.setString(1,cid);
			resultset=preparedStatement.executeUpdate();
 
			/*if(resultset.next())
			{
				bean = new DonorBean();
				bean.setName(resultset.getString(1));
				bean.setEmail(resultset.getString(2));
				bean.setPassword(resultset.getString(3));
				bean.setPhonenumber(resultset.getString(4));
				bean.setAddress(resultset.getString(5));
				bean.setCity(resultset.getString(6));
				bean.setZipcode(resultset.getString(7));
				bean.setCountry(resultset.getString(8));
 
 
			}*/
 
			if( resultset == 1)
			{
				logger.info("delete   Successfully");
				System.out.println("Deleted succes");
				return bean;
			}
			else
			{
				logger.info("delete Not Found Successfully");
				System.out.println("Customer id is not fopund successfully");
				return null;
			}
 
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new CustomerException(e.getMessage());
		}
		finally
		{
			try 
			{
				//resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
 
				throw new CustomerException("Error in closing db connection");
 
			}
		}
 
}
	
	
	
	//------------------------------------------------------------------//
	
	
	public String loginadmin(String email) throws CustomerException
	{
		Connection con=DBConnection.getInstance().getConnection();
		ResultSet resultSet;
		LoginBean Bean=new LoginBean();
		String pwd=null;
		try
		{
			PreparedStatement PreparedStatement= con.prepareStatement(QueryMapper.LOGIN_QUERY);
			PreparedStatement.setString(1, email);
			resultSet=PreparedStatement.executeQuery();
			while (resultSet.next()) 
			{
 
				//Bean=new LoginBean();
				 pwd=resultSet.getString(1);
 
			}
 
 
		}
		catch(Exception exception)
		{
			logger.error(exception.getMessage());
			throw new CustomerException("Tehnical problem occured. Refer log");
		}
		return pwd;
 
	}
	
	
	
	
	
	
	

	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	deleteCustomerDetails(String donorId)
	 - Input Parameters	:	donorId
	 - Return Type		:	DonorBean
	 - Throws			:  	DonorException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	18/11/2018
	 - Description		:	deleteCustomerDetails
	 ********************************************************************************************************/
	public String updateCustomerDetails(CustomerBean donor) throws CustomerException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
 
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
 
		String donorId=null;
 
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_DONAR_DETAILS_QUERY);
			//public final String UPDATE_QUERY="update customer set name=?,city=?,EMAIL=? where customer_ID=?";
 
			preparedStatement.setString(2,donor.getPassword());			
			preparedStatement.setString(1,donor.getEmail());
 
			preparedStatement.setString(3,donor.getCid());
			 
 
			queryResult=preparedStatement.executeUpdate();
 
			//preparedStatement = connection.prepareStatement(QueryMapper.DONARID_QUERY_SEQUENCE);
			/*resultSet=preparedStatement.executeQuery();
 
			if(resultSet.next())
			{
				donorId=resultSet.getString(1);
 
			}*/
 
			if(queryResult==0)
			{
				logger.error("Updation  failed ");
				throw new CustomerException("updationb donor details failed ");
 
			}
			else
			{
				logger.info("updation details added successfully:");
				return donorId;
			}
 
		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new CustomerException("Tehnical problem occured refer log");
		}
 
		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustomerException("Error in closing db connection");
 
			}
		}
 
 
	}
 
 

	//------------------------ 1. Donor Application --------------------------
	/*******************************************************************************************************
	 - Function Name	:	retriveAllDetails()
	 - Input Parameters	:	
	 - Return Type		:	List
	 - Throws		    :  	DonorException
	 - Author	     	:	CAPGEMINI
	 - Creation Date	:	18/11/2018
	 - Description		:	return list
	 ********************************************************************************************************/

	public List<CustomerBean> retriveAllDetails() throws CustomerException {
		
		Connection con=DBConnection.getInstance().getConnection();
		int donorCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<CustomerBean> donorList=new ArrayList<CustomerBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				CustomerBean bean=new CustomerBean();
				bean.setCid(resultset.getString(1));
				bean.setEmail(resultset.getString(2));
				bean.setPassword(resultset.getString(3));
				bean.setPhonenumber(resultset.getString(4));
				bean.setAddress(resultset.getString(5));
				bean.setCity(resultset.getString(6));
				bean.setZipcode(resultset.getString(7));
				bean.setCountry(resultset.getString(8));
				bean.setFullname(resultset.getString(9));
				bean.setRegistrationdate(resultset.getDate(10));
				
				
				
				donorList.add(bean);
				
				donorCount++;
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new CustomerException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CustomerException("Error in closing db connection");

			}
		}
		
		if( donorCount == 0)
			return null;
		else
			return donorList;
	}


	





}
