package com.capgemini.customerapplication.dao;

public interface QueryMapper {
	
	public static final String RETRIVE_ALL_QUERY="SELECT cid,email,password,phonenumber,address,city,zipcode,country,fullname,registereddate FROM customer";
	public static final String UPDATE_DONAR_DETAILS_QUERY="UPDATE customer set email = ?,password= ?  WHERE  cid=?";
	public static final String INSERT_QUERY="INSERT INTO customer VALUES(cid_sequence.NEXTVAL,?,?,?,?,?,?,?,?,SYSDATE)";
	public static final String DONARID_QUERY_SEQUENCE="SELECT cid_sequence.CURRVAL FROM DUAL";


	public static final String DELETE_DONAR_DETAILS_QUERY="delete  from customer where cid=?";
	
	public static final String LOGIN_QUERY="SELECT PASSWORD FROM USER_PASS WHERE EMAIL=?";
	
}
