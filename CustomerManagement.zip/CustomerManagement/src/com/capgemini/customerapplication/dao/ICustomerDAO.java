package com.capgemini.customerapplication.dao;

import java.util.List;

import com.capgemini.customerapplication.bean.CustomerBean;
import com.capgemini.customerapplication.exception.CustomerException;

public interface ICustomerDAO 
{
	public String addCustomerDetails(CustomerBean donor) throws CustomerException;
	public String updateCustomerDetails(CustomerBean donor) throws CustomerException;
	public List<CustomerBean> retriveAllDetails()throws CustomerException;
	public CustomerBean deleteCustomerDetails(String donorId) throws CustomerException;
}
