package com.capgemini.custapplication.bean;

import java.util.Date;

public class CustBean 
{
	private int custid;
	private String email;
	private String fullname;
	private String password;
	private String confirmpassword;
	private String phonenumber;
	private String address;
	private String city;
	private String zipcode;
	private String country;
	private Date regestrationdate;
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public void setRegestrationdate(Date regestrationdate) {
		this.regestrationdate = regestrationdate;
	}
	public int getCustid() {
		return custid;
	}
	public String getEmail() {
		return email;
	}
	public String getFullname() {
		return fullname;
	}
	public String getPassword() {
		return password;
	}
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public String getAddress() {
		return address;
	}
	public String getCity() {
		return city;
	}
	public String getZipcode() {
		return zipcode;
	}
	public String getCountry() {
		return country;
	}
	public Date getRegestrationdate() {
		return regestrationdate;
	}
	/*@Override
	public String toString() {
		return " custid="+ custid +"\n email=" + email +"\n fullname=" +fullname +
				"\n city="+ city +"\n country="+ country +"\n regestrationdate="
				+ regestrationdate ;
	}*/
	public CustBean()
	{
		super();
	}
	
	public CustBean (int custid,String email,String fullname,String city,String country, Date regestrationdate)
	{
		super();
		this.custid=custid;
		this.email=email;
		this.fullname=fullname;
		this.city=city;
		this.country=country;
		this.regestrationdate=regestrationdate;
		
	}
	
	
}
