package com.capgemini.custapplication.dao;

import java.util.List;

import com.capgemini.custapplication.bean.CustBean;
import com.capgemini.custapplication.exception.CustException;

public interface ICustDAO
{
  
	public String addCustDetails(CustBean cu) throws CustException;
	public void updateCustDetails(String user,String email,String name) throws CustException;
	public List<CustBean> retriveAllDetails() throws CustException;
	public void deleteCustDetails(String cust1) throws CustException;
	public String loginadmin(String email) throws CustException;
}
