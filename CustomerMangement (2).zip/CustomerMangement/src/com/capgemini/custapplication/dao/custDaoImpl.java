package com.capgemini.custapplication.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
//import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.custapplication.bean.CustBean;
import com.capgemini.custapplication.exception.CustException;
import com.capgemini.custapplication.util.*;

public class custDaoImpl implements ICustDAO
{
	
	Logger logger=Logger.getRootLogger();
	public custDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	PreparedStatement preparedStatement=null;		
	ResultSet resultSet = null;
	
	public String addCustDetails(CustBean cu) throws CustException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String custId=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			preparedStatement.setString(1,cu.getEmail());			
			preparedStatement.setString(2,cu.getFullname());
			preparedStatement.setString(3,cu.getPassword());
			preparedStatement.setString(4,cu.getConfirmpassword());
			preparedStatement.setString(5,cu.getPhonenumber());
			preparedStatement.setString(6,cu.getAddress());
			preparedStatement.setString(7,cu.getCity());
			preparedStatement.setString(8,cu.getZipcode());
			preparedStatement.setString(9,cu.getCountry());
						
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.CUSTID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				custId=resultSet.getString(1);
				
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new CustException("Inserting customer details failed ");

			}
			else
			{
				logger.info("customer details added successfully:");
				return custId;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new CustException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustException("Error in closing db connection");

			}
		}
		
		
	}
	public void updateCustDetails(String user,String email,String name) throws CustException 
	{
	 
	 
	Connection connection = DBConnection.getInstance().getConnection();	
	 
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		int queryResult=0;
		CustBean bean;
	 
	 
	    try
	    {
	 
	    	int idd= Integer.parseInt(user);
	    	preparedStatement=connection.prepareStatement(QueryMapper.UPDATE_CUST_DETAILS_QUERY);
	    	preparedStatement.setInt(3,idd);
	    	preparedStatement.setString(2,name );
	    	preparedStatement.setString(1,email );
	    	queryResult=preparedStatement.executeUpdate();
	 
	    	if(queryResult==0)
			{
				logger.error("failed in updating ");
				throw new CustException("updation user details failed :user id doesn't exists");
	 
			}
			else
			{
				System.out.println("user details updated successfully:");
				logger.info("user details updated successfully:");
				//return bean ;
			}
	 
	    }
	    catch (SQLException sqlException) 
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new CustException("Error in closing db connection");
	 
		}
	    finally 
	    {
	    	try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustException("Error in closing db connection");
	 
			}
	 
	 
	    }
		}
	
	
	public List<CustBean> retriveAllDetails() throws CustException
	{
		
		Connection con=DBConnection.getInstance().getConnection();
		int custCount = 0;
		
		PreparedStatement ps=null;
		ResultSet resultset = null;
		
		List<CustBean> custList=new ArrayList<CustBean>();
		try
		{
			ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
			resultset=ps.executeQuery();
			
			while(resultset.next())
			{	
				CustBean bean=new CustBean();
				bean.setCustid(resultset.getInt(1));
				bean.setEmail(resultset.getString(2));
				bean.setFullname(resultset.getString(3));
				bean.setCity(resultset.getString(4));
				bean.setCountry(resultset.getString(5));
				bean.setRegestrationdate(resultset.getDate(6));
				
				//CUSTID,EMAIL,FULLNAME,CITY,COUNTRY,REGESTRATIONDATE
				
				
				custList.add(bean);
				
				custCount++;
			}			
			
		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new CustException("Tehnical problem occured. Refer log");
		}
		
		finally
		{
			try 
			{
				resultset.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new CustException("Error in closing db connection");

			}
		}
		
		if( custCount == 0)
			return null;
		else
			return custList;
	}
	
	
	
	
	public void deleteCustDetails(String cust1) throws CustException
	{
		 
		Connection connection = DBConnection.getInstance().getConnection();	
		 
			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			int queryResult1=0;
			CustBean bean;
		 
		 
		    try
		    {
		 
		    	int i= Integer.parseInt(cust1);
		    	preparedStatement=connection.prepareStatement(QueryMapper.DELETE_CUST_DETAILS_QUERY);
		    	preparedStatement.setInt(1,i);
		    	queryResult1=preparedStatement.executeUpdate();
		 
		    	if(queryResult1==0)
				{
					logger.error("failed in updating ");
					System.out.println("CUSTOMER ID NOT FOUND");
					//throw new CustException("updation user details failed ");
		 
				}
				else
				{
					System.out.println("DELETED SUCCESSFULLY");
					logger.info("CUSTOMER details updated successfully:");
					//return bean ;
				}
		 
		    }
		    catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustException("Error in closing db connection");
		 
			}
		    finally 
		    {
		    	try 
				{
					//resultSet.close();
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					logger.error(sqlException.getMessage());
					throw new CustException("Error in closing db connection");
		 
				}
		 
		 
		    }
			}
	
	public String loginadmin(String email) throws CustException
	{
		Connection con=DBConnection.getInstance().getConnection();
		ResultSet resultSet;
		CustBean Bean=new CustBean();
		String pwd=null;
		int t=0;
		try
		{
			PreparedStatement PreparedStatement= con.prepareStatement(QueryMapper.LOGIN_QUERY);
			PreparedStatement.setString(1, email);
			resultSet=PreparedStatement.executeQuery();
			//System.out.println(" sdf");
			while (resultSet.next()) 
			{
 
				//Bean=new LoginBean();
				 pwd=resultSet.getString(1);

				t++; 
			}
 
 
		}
		catch(Exception exception)
		{
			logger.error(exception.getMessage());
			throw new CustException("Tehnical problem occured. Refer log");
		}
		if(t==1) 
		{
		return pwd;
		}
		else
		{
			throw new CustException("invalid details");
		}
		
	}
		




}

