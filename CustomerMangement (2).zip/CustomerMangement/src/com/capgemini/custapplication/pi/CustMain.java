package com.capgemini.custapplication.pi;


import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.custapplication.bean.CustBean;
import com.capgemini.custapplication.exception.CustException;
import com.capgemini.custapplication.service.CustServiceImpl;
import com.capgemini.custapplication.service.ICustService;

public class CustMain {

	static Scanner sc = new Scanner(System.in);
	static ICustService custService = null;
	static CustServiceImpl custServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws CustException
	{
		PropertyConfigurator.configure("resources//log4j.properties");
		CustBean custBean = null;

		String custid = null;
		int option = 0;
		try
		{
		System.out.println("--------------WELCOME------------------");
		
		 System.out.println("enter the email :");
		 String loginemail = sc.next();
		 System.out.println("enter the password :");
		 String pwd = sc.next();
		 custService =new CustServiceImpl();

		String realpwd= custService.loginadmin(loginemail);
         
		 if (realpwd.equals(pwd))
		 {
			 System.out.println("----------------------------------------");
			 System.out.println("SUCCESSFULLY LOGIN INTO CUSTOMER MANAGEMENT");
			 
		while (true) {
			// show menu
			//System.out.println();
			System.out.println("______________________________");
			System.out.println("CUSTOMER MANAGEMENT ");
			System.out.println("_______________________________");
			System.out.println("1.INSERT CUSTOMER DETAILS ");
			System.out.println("2.UPDATE CUSTOMER");
			System.out.println("3. LISTING CUSTOMERS");
			System.out.println("4.DELETE ");
			System.out.println("5.EXIT");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (custBean == null) {
						custBean = populateCustBean();
						// System.out.println(donorBean);
					}

					try {
						custService = new CustServiceImpl();
						custid = custService.addCustDetails(custBean);

						System.out.println("Customer details  has been successfully registered ");
						System.out.println("Customer  ID Is: " + custid);

					}
					catch (CustException custException) {
						logger.error("exception occured", custException);
						System.err.println("ERROR : "+ custException.getMessage());
					}
					finally {
						custid = null;
						custService = null;
						custBean = null;
					}

					break;

				case 2:

			
					try 
					{
					custServiceImpl = new CustServiceImpl();
					System.out.println("enter the user's id to edit");
					int idd=sc.nextInt();
					System.out.println("enter the new email");
					String email=sc.next();
					System.out.println("enter the name");
					String name=sc.next();
					CustBean bean=new CustBean();
		            bean.setEmail(email);
		            bean.setFullname(name);
		            custService.updateCustDetails(idd,email,name);
					}
					catch(CustException e)
					{
						System.out.println(e.getMessage());
					}
		 
					break;
					
				case 3:

					custService = new CustServiceImpl();
					try {
						List<CustBean> custList = new ArrayList<CustBean>();
						custList = custService.retriveAll();

						if (custList != null)
						{
							Iterator<CustBean> i = custList.iterator();
							if(i.hasNext())
							{
								
							System.out.println("-----------------------------------------------------------------------------------------------------------------------------------");
							System.out.printf("%10s %30s %20s %20s %20s %20s","CUSTID","EMAIL","FULLNAME","CITY","COUNTRTY","REGESTRATION-DATE");
							System.out.println();
							System.out.println("-------------------------------------------------------------------------------------------------------------------------------------");
							for(CustBean custbean: custList)
							//while (i.hasNext())
							{
								System.out.format("%10s %30s %20s %20s %20s %20s",custbean.getCustid(),custbean.getEmail(),custbean.getFullname(),custbean.getCity(),custbean.getCountry(),custbean.getRegestrationdate());
								System.out.println();
							}
							System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------");
							}
						}
							
							
							else {
							System.out.println("NO DETAILS FOUND");
						}

					}

					catch (CustException e) {

						System.out.println("Error  :" + e.getMessage());
					}

					break;
				case 4:
                       try {
					custService = new CustServiceImpl();
					System.out.println("ENTER CUSTOMER ID TO DELETE");
					int idd1=sc.nextInt();
					custService.deleteCustDetails(idd1);
                       }
                       catch(CustException e)
                       {
                    	System.out.println(e.getMessage());   
                       }
					
					break;
					
				case 5:

					System.out.print("Exit Customer Management");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try
		 else//IF
		 {
			 System.out.println("INVALID EMAIL AND PASSWORD");
		 }
		}//TRY
		
		catch(CustException e)
		{
			
			System.err.println(e.getMessage());
		}
		
		 
	}	
	
	
	private  static CustBean populateCustBean() {

		// Reading and setting the values for the donorBean
		
		CustBean custBean = new CustBean();

		System.out.println("\n Enter Details");

		System.out.println("Enter customer email: ");
		custBean.setEmail(sc.next());
		
		System.out.println("Enter customer name: ");
		Scanner sc1= new Scanner(System.in);
		custBean.setFullname(sc1.nextLine());
		
		System.out.println("Enter customer password: ");
		custBean.setPassword(sc.next());

		System.out.println("Enter customer confirm password:");
		custBean.setConfirmpassword(sc.next());
        
		System.out.println("Enter phone number:");
		custBean.setPhonenumber(sc.next());
		
		System.out.println("Enter address:");
		Scanner sc2= new Scanner(System.in);
		custBean.setAddress(sc.nextLine());
 		
		System.out.println("Enter city:");
		Scanner sc3= new Scanner(System.in);
		custBean.setCity(sc3.nextLine());

		
		System.out.println("Enter zipcode : ");
		try {
			custBean.setZipcode(sc.next());
		}
		catch (InputMismatchException inputMismatchException) {
			sc.nextLine();
			System.err.println("Please enter a numeric value for age amount, try again");
			}
	
		System.out.println("Enter country:");
		custBean.setCountry(sc.next());

		custService = new CustServiceImpl();

		try {
			custService.validatecust(custBean);
			return custBean;
		}
		catch (CustException custException) {
			logger.error("exception occured", custException);
			System.err.println("Invalid data:");
			System.err.println(custException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
