package com.capgemini.custapplication.service;

import java.util.List;

import com.capgemini.custapplication.bean.CustBean;
import com.capgemini.custapplication.exception.CustException;

public interface ICustService {

	public String addCustDetails(CustBean cust) throws CustException;
	public List<CustBean> retriveAll()throws CustException;
	public String loginadmin(String email) throws CustException ;
	public void validatecust(CustBean bean) throws CustException;
	public void updateCustDetails(int d, String email, String name) throws CustException;
	public void deleteCustDetails(int idd1) throws CustException;
}
