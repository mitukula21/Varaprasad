##Please run the below DDL query before you execute this application.  

 create table distance_calculator(distance_id number(20) primary key,source varchar2(20),destination varchar2(12),dist_in_km number(20),dist_in_miles number(5));