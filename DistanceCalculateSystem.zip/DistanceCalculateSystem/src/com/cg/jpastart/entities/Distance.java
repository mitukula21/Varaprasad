package com.cg.jpastart.entities;
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="distance_calculator")
public class Distance {
	private static final long serialVersionUID = 1L;
	@Id
	private int distance_id;
	private String source;
	private String destination;
	private int dist_in_km;
	private  int dist_in_miles;
	
	
	
	
	
	public double getDistance(int dist_in_km,int dist_in_miles)
	{
		double totaldistance;
	return   totaldistance = (dist_in_km/1000)+(dist_in_miles/1609.34);
	
		
	}

	public int getDistance_id() {
		return distance_id;
	}

	public void setDistance_id(int distance_id) {
		this.distance_id = distance_id;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public int getDist_in_km() {
		return dist_in_km;
	}

	public void setDist_in_km(int dist_in_km) {
		this.dist_in_km = dist_in_km;
	}

	public int getDist_in_miles() {
		return dist_in_miles;
	}

	public void setDist_in_miles(int dist_in_miles) {
		this.dist_in_miles = dist_in_miles;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
