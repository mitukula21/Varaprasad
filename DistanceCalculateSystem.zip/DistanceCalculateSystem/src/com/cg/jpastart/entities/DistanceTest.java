package com.cg.jpastart.entities;
import java.io.IOException;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DistanceTest {

	public static void main(String[] args) throws IOException {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Distance tr=new Distance();
		Scanner sc=new Scanner(System.in);
		boolean a=true;
		while(a) {
		System.out.println("enter distance_id");
		int id=sc.nextInt();
		System.out.println("enter source");
		String str1=sc.next();
		System.out.println("enter destination");
		String str2=sc.next();
		System.out.println("enter distance in km");
		int dist_in_km=sc.nextInt();
		System.out.println("enter distance in miles");
		int dist_in_miles=sc.nextInt();
		
		
		 
		tr.setDistance_id(id);
		tr.setSource(str1);
		tr.setDestination(str2);
		tr.setDist_in_km(dist_in_km);
		tr.setDist_in_miles(dist_in_miles);
		
		tr.getDistance(dist_in_km, dist_in_miles);
		em.persist(tr);
		System.out.println("Added one trainee information to database.");
		System.out.println("Total distance in metres:"+tr.getDistance(dist_in_km, dist_in_miles));
			em.getTransaction().commit();
		em.close();
		factory.close();
		a=false;
	}
			
}
}

